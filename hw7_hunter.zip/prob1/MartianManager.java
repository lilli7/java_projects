package prob1;

import java.util.ArrayList;
import java.util.Collections;

public class MartianManager {
	protected ArrayList<Martian> martians = new ArrayList<>();
	protected ArrayList<Teleporter> teleporters = new ArrayList<>();
	
	public MartianManager() {
		
	}
	public boolean addMartian(Martian m) {
		if(!martians.equals(m)) {
			martians.add(m);
			if (m instanceof Teleporter) {
				//Teleporter t = (Teleporter)m;
				teleporters.add((Teleporter)m);
			}
			return true;
		}
		return false;

	}
	
	public ArrayList<Martian> battle(ArrayList<Martian> invaders){
		ArrayList<Martian> deadmartians = new ArrayList<>();
		for(Martian m: martians) {
			for(Martian in: invaders) {
				if(in.getVolume() > getPower(m)) {
					martians.remove(m);
					deadmartians.add(m);
					break;
				}
			}
		}
		return deadmartians;
		/* int power = 0;
		for (Martian m : martians) {
			if (m instanceof RedMartian) {
				power = (m.getVolume()+ ((RedMartian) m).getTenacity());
				if (invaders > m.getPower) {
					return m;
				}
			}
		}*/
	}
	private int getPower(Martian m) {
		for (Martian i : martians) 
			//int power = i.getVolume();
			if (m instanceof RedMartian) {
				int pwer = (m.getVolume()+ ((RedMartian) m).getTenacity());
				return pwer;
			}
			return (m.getVolume());
			
		
		
	}
	
	public boolean contains(int id) {
		for (Martian m : martians) {
			int id2 = id;
			if (m.getId() == (id2)) {
			//if(martians.contains(id2)) {
				return true;
			}
		}
		return false;
	}
	
	public Martian getMartianAt(int i) {
		if( i>=0 && i<martians.size()) {
			return martians.get(i);
		}
		return null;


	}
	public Martian getMartianClosestTo(int id) {
		int diff;
		int pos = 0;

		diff = Math.abs(martians.get(0).getId()-id);
		
		for(int i = 1; i < martians.size(); i++)
		{
			if((martians.get(i).getId() - id) < diff)
			{
				diff = martians.get(i).getId() - id;
				pos = i;
			}
		}
		return getMartianAt(pos);
	}
	
	public Martian getMartianClosestTo(Martian m) {
		int diff;
		int pos = 0;

		diff = Math.abs(martians.get(0).getId()- m.getId());
		
		for(int i = 1; i < martians.size(); i++)
		{
			if((martians.get(i).getId() - m.getId()) < diff)
			{
				diff = martians.get(i).getId() - m.getId();
				pos = i;
			}
		}
		return getMartianAt(pos);
		
	}
	public Martian getMartianWithId(int id) {
		int diff;
		int pos = 0;

		diff = Math.abs(martians.get(0).getId()-id);
		
		for(int i = 1; i < martians.size(); i++)
		{
			if((martians.get(i).getId() - id) < diff)
			{
				diff = martians.get(i).getId() - id;
				pos = i;
			}
		}
		return getMartianAt(pos);

	}
	public int getNumMartians() {
		return martians.size();
	}
	public int getNumTeleporters() {
		return teleporters.size();
	}
	public ArrayList<Martian> getSortedMartians() {
		ArrayList<Martian> sorted = new ArrayList<>(martians);
		Collections.sort(sorted);
		return sorted;
	}
	public Teleporter getTeleporterAt(int i) {
		if( i>=0 && i<teleporters.size()) {
			return teleporters.get(i);
		}
		return null;
	}
	public String groupSpeak() {
		String msg = "";
		for(Martian m : martians) {
			msg += m.speak() + " ";
		}
		return msg;
		
	}
	public String groupTeleport(String dest) {
		String msg = " ";
		for(Martian m : martians)
		{
			if(m instanceof Teleporter)
			{
			msg += ((Teleporter) m).teleport(dest) + "\n";
			}
		}
		return msg;
	}
	public void obliterateTeleporters() {
		
		teleporters.clear();
		/*for(Martian m : martians)
		{
			if(m instanceof Teleporter)
			{
				martians.remove(m);
			}
		}
		
		for(Teleporter t : teleporters)
		{
			if(t instanceof Teleporter)
			{
				martians.remove(t);
			}
		}*/
	}
	public Martian removeMartian(int id) {
		/*for (Martian m : martians) {
			if(m.getId() == id) {
				martians.remove(m);
				return m;
			}	
		}
		return null;*/
		for(Martian m: martians) {
			if((m.getId()==(id))) {
			return null;
			}
		}	
		Martian mn = martians.get(id);
		martians.remove(mn);
		if(mn instanceof Teleporter) {
			Teleporter t = (Teleporter)mn;
			teleporters.remove(t);
		}
		return mn; ////////

	}
	public String toString() {
		String msg ="Martians:\n";
		for(Martian m : martians) {
			msg += m + "\n";
		}
		msg += "\nTeleporters\n";
		for(Teleporter t : teleporters) {
			msg += t + "\n";
		}	
		return msg;
	}
}

