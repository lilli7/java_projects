package prob1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

public class MartianManagerWrite {

	public static void main(String[] args) {
		// Change the package name if yours is different
		String outFileName = "src/prob1/inMartians1.txt";
		String[] martianIds = {"inMartians1.txt", "inMartians2.txt", "inMartians3.txt", "inMartians4.txt", "inMartians5.txt",
				"inMartians6.txt"};
		testWriteMartians(outFileName);
		
		// To test that you have written in the proper format, obviously open the output
		// file and scan it. But, then to really test go back to MartianManagerRead.java
		// and test reading in the file you just wrote.
	}

	// Do not alter this method.
	public static void testWriteMartians(String fileName) {
		MartianManager mm = new MartianManager();
		mm.addMartian(new GreenMartian(1, 2));
		mm.addMartian(new RedMartian(2, 3, 4));
		mm.addMartian(new RedMartian(3, 4, 5));
		mm.addMartian(new GreenMartian(4, 5));
		mm.addMartian(new RedMartian(5, 6, 7));
		
		writeMartians(fileName, mm);
	}

	/**
	 *  YOU WILL WRITE THIS METHOD.
	 *  
	 *  Write the martians in the MartianManager to the file. The format is exactly the same
	 *  as specified in the HW 7 document for reading valid data: G I V or R I V T.
	 *  In addition, it should display a report to the console stating the name of the file
	 *  and how many martians were added. For example: File: out3.txt, Num Martians written:5
	 */
	public static void writeMartians(String fileName, MartianManager mm) {
		File file = new File(fileName);
    	// YOU WILL WRITE CODE HERE, or possibly write a helper method, 
    	// e.g. writeMartiansFile(File file, MartianManager mm)
		
		File outFile = new File("src/prob1/inMartians1.txt");

		
		try {
			PrintWriter writer = new PrintWriter( outFile );

			for(int i = 0; i < mm.getNumMartians(); i++)
			{
				
				if(mm.getMartianAt(i) instanceof RedMartian)
				{
					String name = "R";
					int id = mm.getMartianAt(i).getId();
					int tenacity = ((RedMartian) mm.getMartianAt(i)).getTenacity();
					int vol = mm.getMartianAt(i).getVolume();
					
					writer.print(name + " " + id + " " + vol + " " + tenacity);
				}
				
				if(mm.getMartianAt(i) instanceof GreenMartian)
				{
					String name = "G";
					int id = mm.getMartianAt(i).getId();
					int vol = mm.getMartianAt(i).getVolume();

					writer.print(name + " " + id + " " + vol);
				}
			
			}
			writer.close();
		}
		catch (IOException ioe) {
			System.out.println("Problem creating file or writing");
		}

		System.out.println("\nNumber martians added:" + mm.getNumMartians());
	}
}

