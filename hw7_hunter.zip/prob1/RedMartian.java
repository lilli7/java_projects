package prob1;

public class RedMartian extends Martian {
private int tenacity;	
	
	public RedMartian(int id, int vol, int ten) {
		super(id, vol);
		this.tenacity = ten;
		// TODO Auto-generated constructor stub
	}
	public RedMartian(int id, int ten) {
		this(id,1,ten);
	}
	
	public int getTenacity() {
		return tenacity;
	}
	
	public String speak() {
		String result = String.format("id = %s, Rubdly Rock", getId());
		return result;
	}
	public String toString() {
		String result = String.format("Red Martian - id = %s, vol = %d, ten = %d", getId(),getVolume(),tenacity);
		return result;
	}
	@Override
	public int compareTo(Martian o) {
		// TODO Auto-generated method stub
		return 0;
	}
}

