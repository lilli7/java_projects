package prob1;

public interface Teleporter {
	String teleport(String dest);
}
