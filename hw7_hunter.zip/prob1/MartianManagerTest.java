package prob1;

import java.util.ArrayList;

public class MartianManagerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//testAddMartian();
		testBattle(); 
		//testcontains();
		//testgetMartianAt();
		//testgetMartianClosestTo();
		//testgetMartianWithId();
		//testgetNumMartians();
		//testgetNumTeleporters();
		//testgetSortedMartians();
		//testgetTeleporterAt();
		//testgroupSpeak();
		//testgroupTeleport();
		testobliterateTeleporters();
		testremoveMartian();
		//testtoString();
		
	}
	//this method adds martian to arraylist and teleporter if martian is an instance of it
	private static void testAddMartian() {
		System.out.println("\ntestAddMartian()");
		MartianManager mm = new MartianManager();
		System.out.println("Number of Martians = " + mm.getNumMartians());
		mm.addMartian(new RedMartian(1,2,3));
		mm.addMartian(new GreenMartian(2,1));
		System.out.println("Adding 2 = " + mm.getNumMartians());
		
	}	
	//returns an array of martians that have less power then invaders
	private static void testBattle() {
		System.out.println("\ntestBattle()");
		ArrayList<Martian> invaders = new ArrayList<>();
		System.out.println("adding 2 invaders, power 20 and power 3");
		invaders.add(new GreenMartian(122,20));
		invaders.add(new GreenMartian(121,3));
		System.out.println(invaders);
		MartianManager mm = new MartianManager();
		mm.addMartian(new RedMartian(11,2,3));
		mm.addMartian(new GreenMartian(22,1));
		System.out.println("adding 2 martians, power 5 and power 1");
		System.out.println("remaining martians after battle:");
		
		System.out.println(mm.battle(invaders));
	}
	//returns martian that contains the id entered
	private static void testcontains() {
		System.out.println("\ntestcontains()");
		MartianManager mm = new MartianManager();
		System.out.println("Adding Martian");
		mm.addMartian(new RedMartian(1,2,3));
		System.out.println("Searching Martian");
		System.out.println(mm.contains(1));
		System.out.println("Searching nonexistent Martian");
		System.out.println(mm.contains(4));
	}
	//returns martian at specific position
	private static void testgetMartianAt() {
		System.out.println("\ntestgetMartianAt()");
		MartianManager mm = new MartianManager();
		System.out.println("Adding Martian");
		mm.addMartian(new RedMartian(1,2,3));
		System.out.println("Searching martian in first spot");
		System.out.println(mm.getMartianAt(0));
		System.out.println("Searching martian in nonexistent spot");
		System.out.println(mm.getMartianAt(5));
	}
	//returns martian closest to the specific id or martian
	private static void testgetMartianClosestTo() {
		System.out.println("\ntestgetMartianClosestTo()");
		MartianManager mm = new MartianManager();
		mm.addMartian(new RedMartian(1,2,3));
		mm.addMartian(new GreenMartian(2,3));
		mm.addMartian(new RedMartian(4,5,6));
		mm.addMartian(new GreenMartian(6,7));
		System.out.println(mm.getMartianClosestTo(2));
		System.out.println();
	}
	//returns martian if id matches input id
	private static void testgetMartianWithId() {
		System.out.println("\ntestgetMartianWithId()");
		MartianManager mm = new MartianManager();
		System.out.println("Adding Red and Green Martian ");
		mm.addMartian(new RedMartian(1,2,3));
		mm.addMartian(new GreenMartian(2,3));
		System.out.println("Searching Red Martians id");
		System.out.println(mm.getMartianWithId(1));
		System.out.println("Searching Green Martians id");
		System.out.println(mm.getMartianWithId(2));
	}
	//returns total number of martians
	private static void testgetNumMartians() {
		System.out.println("\ntestgetNumMartians()");
		MartianManager mm = new MartianManager();
		System.out.println("Adding Martian");
		mm.addMartian(new RedMartian(1,2,3));
		System.out.println(mm.getNumMartians());
		System.out.println("Adding 2 more Martians");
		mm.addMartian(new RedMartian(5,2,3));
		mm.addMartian(new RedMartian(4,2,3));
		System.out.println(mm.getNumMartians());
	}
	//returns total number of teleporters
	private static void testgetNumTeleporters() {
		System.out.println("\ntestgetNumTeleporters()");
		MartianManager mm = new MartianManager();
		System.out.println("Num teleporters before teleporting");
		System.out.println(mm.getNumTeleporters());
		Teleporter tp = new GreenMartian(1,3);
		GreenMartian gm = new GreenMartian(1,3);
		gm.teleport("Mars");
		
		if( gm instanceof Teleporter ) {
			Teleporter t = (Teleporter)gm;
		   t.teleport("Mars");
		}
		mm.addMartian(gm);
		System.out.println("Num teleporters after teleporting 1 martian");
		
		//System.out.println(gm.teleport("Mars"));
		System.out.println(mm.getNumTeleporters());
	}
	//sorts the arraylist of martians and returns it
	private static void testgetSortedMartians() {
		System.out.println("\ntestgetSortedMartians()");
		MartianManager mm = new MartianManager();
		mm.addMartian(new RedMartian(9,2,3));
		mm.addMartian(new RedMartian(5,2,3));
		mm.addMartian(new RedMartian(6,2,3));
		mm.addMartian(new GreenMartian(4,9));
		System.out.println("Martians:");
		System.out.println(mm);
		
		ArrayList<Martian> sorted = mm.getSortedMartians();
		System.out.println("\nMartians returned from p.getSortedMartians():");
		for(Martian m : sorted) {
			System.out.println(m);
		}

		System.out.println("\nMartians after sort:");
		System.out.println(mm);
	}
	//returns martian teleporter at specific position
	private static void testgetTeleporterAt() {
		System.out.println("\ntestgetTeleporterAt()");
		MartianManager mm = new MartianManager();
		mm.addMartian(new RedMartian(9,2,3));
		mm.addMartian(new RedMartian(5,2,3));
		mm.addMartian(new RedMartian(6,2,3));
		mm.addMartian(new GreenMartian(4,9));
		System.out.println(mm.getTeleporterAt(0));
		System.out.println();

	}
	//returns string of all martians in array speaking
	private static void testgroupSpeak() {
		System.out.println("\ntestgroupSpeak()");
		MartianManager mm = new MartianManager();
		mm.addMartian(new RedMartian(9,2,3));
		mm.addMartian(new GreenMartian(2,3));
		System.out.println("Adding 2 Martians Red and Green");
		System.out.println(mm.groupSpeak());
	}
	//returns string of all martians teleporting
	private static void testgroupTeleport() {
		System.out.println("\ntestgroupTeleport()");
		MartianManager mm = new MartianManager();
		GreenMartian gm = new GreenMartian(1,3);
		
		mm.addMartian(gm);
		mm.addMartian(new GreenMartian(9,2));
		System.out.println(mm.groupTeleport("MARS"));
	}
	//clears array of teleporters from both martians and teleporter
	private static void testobliterateTeleporters() {
		System.out.println("\ntestobliterateTeleporters()");
		MartianManager mm = new MartianManager();
		System.out.println("Num teleporters:");
		System.out.println(mm.getNumTeleporters());
		mm.addMartian(new GreenMartian(22,3));
		mm.addMartian(new GreenMartian(21,3));
		mm.addMartian(new GreenMartian(23,3));
		System.out.println("Adding 3 Teleporters:");
		System.out.println(mm.getNumTeleporters());
		System.out.println("Obliterating Teleporters:");
		mm.obliterateTeleporters();
		System.out.println(mm.getNumTeleporters());
		//if( gm instanceof Teleporter ) {
			//Teleporter t = (Teleporter)gm;
		   //t.teleport("Mars");
		//}
		//mm.addMartian(gm);
	}
	//removes martian from arraylist
	private static void testremoveMartian() {
		System.out.println("\ntestremoveMartian()");
		MartianManager mm = new MartianManager();
		GreenMartian gm = new GreenMartian(1,3);
		mm.addMartian(new RedMartian(5,2,3));
		mm.addMartian(gm);
		System.out.println("Adding 2 Martians");
		System.out.println("Number of martians = " + mm.getNumMartians());
		mm.removeMartian(5);
		System.out.println("Removing 1 Martian ");
		System.out.println("Remaining Martian = " + mm.getNumMartians());
	}
	//returns string of all the martians in arraylist
	private static void testtoString() {
		System.out.println("\ntesttoString()");
		MartianManager mm = new MartianManager();
		System.out.println("Adding 2 Martians Red and Green");
		mm.addMartian(new RedMartian(9,2,3));
		mm.addMartian(new GreenMartian(2,3));
		System.out.println(mm.toString());
	}
}

