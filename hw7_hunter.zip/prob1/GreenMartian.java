package prob1;

public class GreenMartian extends Martian implements Teleporter {

	
	public GreenMartian(int id, int volume) {
		super(id, volume);
		// TODO Auto-generated constructor stub
	}
	public GreenMartian(int id) {
		this(id,1);
	
	}
	
	
	public String speak() {
		String result = String.format("id = %s, Grobldy Grock", getId());
		return result;
	}
	
	public String teleport(String dest) {
		String result = String.format("id = %s, teleporting to %s", getId(),dest);
		return result;
	}
	
	public String toString() {
		String result = String.format("Green Martian - id = %s, vol = %d", getId(),getVolume());
		return result;
	}
	@Override
	public int compareTo(Martian o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}

