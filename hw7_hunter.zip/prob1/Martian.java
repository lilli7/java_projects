package prob1;

public abstract class Martian implements Comparable<Martian>{
	private int id;
	private int volume;
	
	public Martian(int id, int vol) {
		this.id = id;
		this.volume = vol;
	}
	
	public int CompareTo(Martian m) {
		double diff = this.id - m.id;
		if(diff < 0) return -1;
		else if(diff > 0) return 1;
		else return 0;

	}
	
	public boolean equals(Object o) {
		if(o instanceof Martian) {
			return this.getId() ==
					((Martian)o).getId();
		}
		return false;


	}
	public int getId() {
		return id;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int v) {
		this.volume = v;
	}
	
	public String speak() {
		return "Martian";
	}
	public String toString() {
		String result = String.format("id = %d,  vol = %d", id,volume);
		return result;
	}
}

