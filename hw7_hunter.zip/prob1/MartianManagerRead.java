package prob1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MartianManagerRead {

	public static void main(String[] args) {
		// Change the package name if yours is different
		String path = "src/prob1/";
		String[] inFileNames = {"inMartians1.txt", "inMartians2.txt", "inMartians3.txt",
				"inMartians4.txt", "inMartians5.txt", "inMartians6.txt"};
		
		// You will probably want to comment all these out except the first. Then, when it
		// works correctly for the first file, then uncomment the second, etc.
		//testReadMartians(path + inFileNames[0]);
		//testReadMartians(path + inFileNames[1]);
		//testReadMartians(path + inFileNames[2]);
		testReadMartians(path + inFileNames[3]);
		testReadMartians(path + inFileNames[4]);
		testReadMartians(path + inFileNames[5]);
		
		// UNCOMMENT when ready to test reading output file from MartianManagerWriteSolution.java
		 //testReadMartians(path + "outMartians.txt");
	}

	// Do not alter this method.
	public static void testReadMartians(String fileName) {
		MartianManager mm = new MartianManager();
		readMartians(fileName, mm);
	}

	/**
	 *  YOU WILL WRITE THIS METHOD.
	 *  
	 *  This method should (a) read martians from "file" in the format
	 *  shown in the problem statement, (b) build the corresponding
	 *  martian objects (c) and it should display a report to the console.
	 *  The format of the report is found in the HW 7 document in the 
	 *  Requirements section.
	 */
	public static void readMartians(String fileName, MartianManager mm) {
		File file = new File(fileName);
    	// YOU WILL WRITE CODE HERE, or possibly write a helper method, 
    	// e.g. readMartiansFile(File file, MartianManager mm)
		System.out.println("\nFile:" + fileName + ", Martians read and added:");
		int num = 0;
		try {
			Scanner input = new Scanner(file);
			while(input.hasNext()) {
				String line = input.nextLine();
				String[] tokens = line.split("\\s");
				String name = tokens[0];
				
				if(name.substring(0).contentEquals("R")/*||name.substring(0).contentEquals("RED")*/) {
					int id = Integer.parseInt(tokens[1]);
					int vl = Integer.parseInt(tokens[2]);
					int ten = Integer.parseInt(tokens[3]);
					RedMartian rm = new RedMartian(id,vl,ten);
					mm.addMartian(rm);
				}
				else
					if(name.substring(0).contentEquals("G")/*||name.substring(0).contentEquals("GREEN")*/) {
						int id = Integer.parseInt(tokens[1]);
						int vl = Integer.parseInt(tokens[2]);
						//int ten = Integer.parseInt(tokens[3]);
						GreenMartian gm = new GreenMartian(id,vl);
						mm.addMartian(gm);
					}
				else
					num++;

			}

			input.close();
		}
		/*catch( FileNotFoundException e ) {
			System.out.println(e);
		}
		catch( NumberFormatException e ) {
			numILLformed++;
		}
		catch( ArrayIndexOutOfBoundsException e) {
			numILLformed++;
		}*/
		catch(Exception e) {
			num++;
		}
		for(Martian i: mm.martians)
			System.out.println(i);
			
			System.out.println("\nNumber martians added:" + mm.getNumMartians());
			System.out.println("Number of ill formed lines:" + num);
			System.out.println("Number already exist (not added):" + 0);
	}
}

