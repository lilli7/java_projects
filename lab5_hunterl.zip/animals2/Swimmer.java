package animals2;

public interface Swimmer {
	
	public String swim();
	public String dive();


}
