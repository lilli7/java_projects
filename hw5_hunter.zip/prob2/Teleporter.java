package prob2;

public interface Teleporter 
{
	String teleport(String dest);
}
