package prob1;

public class ClassicYellowCake extends Cake
{
	protected String liquid;
	protected String oil;
	protected String eggs;

	public ClassicYellowCake(String cakeMix)
	{
		super(cakeMix);
		this.liquid = liquid;
		this.oil = oil;
		this.eggs = eggs;
		
	}
	
	public String getLiquid()
	{
		liquid = " 1 cup water";
		return liquid;
	}
	
	public String getOil()
	{
		oil =" 1/3 cup vegetable oil";
		return oil;
	}
	
	public String getEggs()
	{
		eggs = " 3 large eggs";
		return eggs;
	}
}
