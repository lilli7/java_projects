package prob2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class BinarySearchTester {

	public static void main( String[] args ) {
		// Test code provided. You should verify that the results you obtain are correct. 
		// Remember, if return is negative (doesn't matter the value), it means items was not found
		// Otherwise, return is location of found item.
		ArrayList<Blob> blobs = new ArrayList<>( Arrays.asList(
				new Blob(3), new Blob(8), new Blob(6), new Blob(5), new Blob(1), new Blob(10)));
		Collections.sort(blobs);
		printBlobList(blobs);
		int[] coolness = {2,3,7,10,15};
		for( int cool : coolness) {
			Blob key = new Blob(cool);
			int loc = binaryBlobSearch(blobs, key);
			String msg = String.format("binaryBlobSearch(blobs,%s)=%d", key, loc);
			System.out.println(msg);
		}
	}

	public static int binaryBlobSearch(ArrayList<Blob> blobs, Blob bKey) {
		// ---> WRITE THIS METHOD <---
		// Write code here to implement as described in problem description.
		// ***Need to write a recursive helper method also.
		return binaryBlobSearch(blobs, bKey,0,blobs.size()-1);
	}

	private static int binaryBlobSearch(ArrayList<Blob> blobs,Blob bKey, int low, int high) {
		
		if(low > high)
			return -(low+1);
		
		else {
			int mid = (low+high)/2;
			
			
			if(bKey.getCoolnessFactor()<blobs.get(mid).getCoolnessFactor())
				return binaryBlobSearch(blobs,bKey,low,mid-1);
			
			else if(bKey.getCoolnessFactor()>blobs.get(mid).getCoolnessFactor())
				return binaryBlobSearch(blobs,bKey,mid+1,high);
			
			else
				
				return mid;
			}

}

	// You may use this method to print a blob list.
	private static void printBlobList(ArrayList<Blob> blobs) {
		StringBuilder sb = new StringBuilder("Sorted Blob list: ");
		for(Blob b : blobs) {
			sb.append(String.format("%s, ", b));
		}
		sb.delete(sb.length()-2, sb.length());
		System.out.println(sb.toString());
	}
}
