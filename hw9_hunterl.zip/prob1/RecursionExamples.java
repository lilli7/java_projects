package prob1;

public class RecursionExamples {

	// Problem 1a
	public static double sumSeries(int n) {
		// *** WRITE CODE HERE ***
		if(n<=1)
		{
			return 1;
		}
		
		else
		{
			return sumSeries(n-1)+ (1/n);
		}
	}

	// Problem 1b
	public static void printReverse2(String s) {
		// *** WRITE CODE HERE ***
		if(s.length()<=3) {
			System.out.print(s);
		}
		else {
			System.out.print(s.charAt(s.length()-1));
			printReverse2(s.substring(0,s.length()-1));//from beginning to last index
		}
	}
	
	// Problem 1c
	public static void printReverse(String s, int n) {
		// *** WRITE CODE HERE ***
		if(s.length()<=1) {
			System.out.print(s);
		}
		else {
			System.out.print(s.charAt(s.length()-1));//prints
			printReverse(s.substring(0,s.length()-1), n);
		}
	}

	// Problem 1d
	public static int countVowels(String s) {
		// *** WRITE CODE HERE ***
		String vowels = "aeiou";
		if(s.length()==0)
		{
			return 0;
		}
		
		else {
			for(char c: s.toCharArray())
			{
				if(vowels.contains(String.valueOf(c)))
				{
					return 1 + countVowels(s.substring(1));
				}
				else
				{
					return countVowels(s.substring(1));
				}
			}
		}
		return 0;
	}
	
	// Problem 1e, requires a helper
	public static int countLength(String[] strs) {
		// *** WRITE CODE HERE ***
		return countLength(strs, 0);
	}
	
	//helper to above
	public static int countLength(String[] strs, int loc)
	{
		if (loc < strs.length)
		{
			return strs[loc].length() + countLength(strs, loc+1);
		}
		else
			return 0;
	}

	// Problem 1f, requires a helper
	public static int getMax(int[] vals) {
		// *** WRITE CODE HERE ***
		return getMax(vals,0,0);
	}
	
	public static int getMax(int[] vals,int pos,int max) {
		// *** WRITE CODE HERE ***
		if (pos<vals.length) {
			if (vals[pos]>max) {
				max=vals[pos];
				return getMax(vals,pos+1,max);
			}
			else return max;
		}
		return max;
	}

	// Problem 1g, requires a helper
	public static int countCode(String msg, String code ) {
		// *** WRITE CODE HERE ***
		return countCode(msg,code,0);
	}

	private static int countCode(String msg, String code, int pos ) {
		if(pos>=msg.length()-2) {
			return 0;
		}
		
		else if (msg.substring(pos,pos+3).equals(code)) {
			return 1+countCode(msg,code,pos+3);
		}
		else
			return countCode(msg,code,pos+1);
	}
}
