package application;
	
import java.util.List;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;


	public class Main7 extends Application {
		
		protected Label lbl;
		protected TextField txfName;
		protected TextArea txaMessage;
		protected Button btnHelloWorld;
		protected Label lblImFeeling;
		protected RadioButton rbDineIn, rbTakeOut, rbDelivery;
		protected ComboBox<String> cmbSalutation;
		protected ListView<String> lvwInterests = new ListView<>();
		private ToggleGroup tGrpDiningChoice;
		
		
		@Override
		public void start(Stage primaryStage) {
			try {
				Pane root = buildGui();
				Scene scene = new Scene(root,400,360);
				primaryStage.setTitle("Dino's Diner");
				
				// Code to display the Gui
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.show();
				btnHelloWorld = new Button("Hello World");
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		private Pane buildTip() {
			VBox saluation = new VBox();
			Label lblSalutation = new Label("Tip");
			saluation.getChildren().add(lblSalutation);

			cmbSalutation = new ComboBox<>();
			cmbSalutation.getItems().addAll("10%", "20%", "30%", "40%");
			cmbSalutation.setValue("20%");

			saluation.getChildren().add(cmbSalutation);

			return saluation;
		}

//		private class ProcessTipEventHandler implements EventHandler<ActionEvent> {
//			@Override
//			public void handle(ActionEvent event) {
//				
//				String interests = "";
//				List<String> allItems = lvwInterests.getSelectionModel().getSelectedItems();
//				for(String interest : allItems) {
//					interests += interest + ", ";
//				}
//				
//			    txaMessage.setText(interests);
//			}
//		}

		
		private Pane buildNameEntry() {
			lbl = new Label("Special Instructions");
			txfName = new TextField();
			
			
			
			// Create HBox and add label and text field
			HBox hBoxName = new HBox();
			hBoxName.getStyleClass().add("h_or_v_box");			
			hBoxName.getChildren().addAll(lbl, txfName);
			return hBoxName;
		}


		
//		private Pane buildOptionsEntry() {
//			
//			// Create VBox and check boxes and add
//			chkHappy = new CheckBox("Dine In");
//			chkHungry = new CheckBox("Take out");
//			chkSleepy = new CheckBox("Delivery");
//			VBox vBoxFeeling = new VBox();
//			vBoxFeeling.getStyleClass().add("h_or_v_box");
//			vBoxFeeling.getChildren().addAll(chkHappy, chkHungry, chkSleepy);
//			return vBoxFeeling;
//		}
		
		private Pane buildDiningChoice() {
			tGrpDiningChoice = new ToggleGroup();
			rbDineIn = new RadioButton("Dine In");
			rbDineIn.setSelected(true);
			rbDineIn.setToggleGroup(tGrpDiningChoice);
			rbTakeOut = new RadioButton("Take Out");
			rbTakeOut.setToggleGroup(tGrpDiningChoice);
			rbDelivery = new RadioButton("Delivery");
			rbDelivery.setToggleGroup(tGrpDiningChoice);

			Button btnProcess = new Button("Process");
			btnProcess.setOnAction(new ProcessDiningEventHandler());

			VBox vbxDiningChoice = new VBox();
			vbxDiningChoice.getStyleClass().add("h_or_v_box");			
			vbxDiningChoice.getChildren().addAll(rbDineIn,rbTakeOut,rbDelivery,btnProcess);

			return vbxDiningChoice;
		}

		
		private class ProcessDiningEventHandler implements EventHandler<ActionEvent> {
			@Override
			public void handle(ActionEvent event) {
				
				RadioButton rad = (RadioButton)tGrpDiningChoice.getSelectedToggle();
				String choice = rad.getText();
				String message = "";
				switch(choice) {
					case "Dine In" : message = "Glad you are dining in with us";
						break;
					case "Take Out" : message = "Meet you at the window";
						break;
					case "Delivery" : message = "We will have it there shortly";
				}
				txaMessage.setText(message);
			}
		}


		private Pane buildFoodItemsEntry() {

			lvwInterests.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
			lvwInterests.getItems().addAll("Burger", "Fries", "Hummus", "Soda");
			lvwInterests.setPrefHeight(150);
			lvwInterests.setPrefWidth(120);
			
			HBox hBox = new HBox();
			hBox.setSpacing(10);
			hBox.getChildren().add(new Label("Select food items"));
			hBox.getChildren().add(lvwInterests);
			return hBox;
		}


		private class CreateOrderEventHandler implements EventHandler<ActionEvent> {
			@Override
			public void handle(ActionEvent event) {
				String receipt = "Order:\n";
				if(rbDineIn.isSelected()) {
					receipt += "Dining in\n";
				}
				if(rbTakeOut.isSelected()) {
					receipt += "Taking out\n";
				}
				
				if(rbDelivery.isSelected()) {
					receipt += "Out for Delivery\n";
				}
				
				List<String> allItems = lvwInterests.getSelectionModel().getSelectedItems();
				for(String interest : allItems) {
					receipt += interest;
				}
		        txaMessage.setText(receipt);			}
			}

		
		private Pane buildGui() {
			GridPane root = new GridPane();
			// Need to write code here...
			Pane p = buildDiningChoice();
			root.add(p, 0, 0);
			
			Pane p1 = buildNameEntry();
			root.add(p1, 0, 1);
			
			Pane p2 = buildTip();
			root.add(p2, 1, 2);
			
			Pane p3 = buildFoodItemsEntry();
			
			root.add(p3, 2, 0);
			
			// Create other controls
			txaMessage = new TextArea();
			txaMessage.setPrefHeight(100);
			txaMessage.setPrefWidth(200);
			btnHelloWorld = new Button("Create Order");
			btnHelloWorld.setOnAction(new CreateOrderEventHandler());
			root.add(btnHelloWorld, 1, 1);
			root.add(txaMessage, 0, 2);
			
			return root;
		}

		// Need to write helper methods here
		
		public static void main(String[] args) {
			launch(args);
		}
	}
