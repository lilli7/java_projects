package prob2;

public class Engineer {

	// Instance variables
	private String name;
	private double hours[];

	// Constructor
	public Engineer(String name, double[] hours) {
		this.name = name;
		this.hours = hours;
	}

	// Getter for name instance variable
	public String getName() {
		return name;
	}

	// Method
	public double getWages(double payRate) {
		double wages = 0.0;
		for(double h : hours) {
			wages += h;
		}
		wages *= payRate;
		return wages;
	}

	// Method
	@Override
	public String toString() {
		return name;
	}
}
