package prob1;

import java.util.Arrays;

import emps.Employee;

public class StoreTester {
	//Employee e = new Employee("Will", 22.33);
	Store s = new Store();
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Store s = new Store(e);
		int i = 0;
		//tests each method
//		s.addEmp();
//		System.out.println(Arrays.toString(s.returnEmps()));
//		s.getEmp(i);
//		s.getNumEmps();
//		s.getTotalHours();
//		s.getTotalPay();
//		s.removeEmployee(i);
//		System.out.println(s.toString());
		
	}
	
	private static void createTestEmployee(String name, double rate)
	{
		Employee e = new Employee("Dave", 20.00);
		Employee e2 = new Employee("Anna", 50.00);
		Employee e3 = new Employee("Paul", 30.00);
		
//		s.addEmp(e2);
//		s.addEmp(e3);
	}
	
	public void testAddEmp1(Employee e) 
	{
		s.addEmp(e);
	}
	
	public void testAddEmp2(Employee e2) 
	{
		s.addEmp(e2);
	}
	
	public void testAddEmp3(Employee e3) 
	{
		s.addEmp(e3);
	}

	public Employee TestGetEmps()
	{
		return s.getEmp(i);
	}

}
