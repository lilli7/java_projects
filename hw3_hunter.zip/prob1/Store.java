package prob1;
import java.util.Arrays;

import emps.Employee;

public class Store 
{
	int numEmps =0;
	private Object e;
	static Employee[] emps = new Employee[20];
	int totHours = 0;
	int totPay = 0;
	
	public static void main (String[]args)
	{
		Employee e = new Employee("Will", 22.33);
		
		//test to verify signatures correct
		Store s = new Store();
		s.addEmp(new Employee("a",10.0));
		e = s.getEmp(0);
		int numEmps = s.getNumEmps();
		double totHours = s.getTotalHours();
		double totPay = s.getTotalPay();
		Employee e2 = s.removeEmployee(0);
		String str = s.toString();
		int i = 0;

	}
	
	public Store() 
	{
		this.e = e;
	}
	
	//Adds the Employee, e in the next available position. 
	//If there are already 20 employees and there is an 
	//attempt to add another then this method should do nothing, 
	//but should not crash.
	public void addEmp(Employee e)
	{
		if (numEmps < emps.length)
		{
			emps[numEmps++] = e;
		}
	}
	
//	//temp method to print current array
//	public Employee[] returnEmps()
//	{
//		return emps;
//	}
	
	//Returns the employee at position i if there is one, 
	//otherwise returns null.
	public Employee getEmp(int i)
	{
		if(i >= 0 && i < numEmps)
		{
			return emps[i];
		}
		return null;
	}
	
	//Returns the number of employees.
	public int getNumEmps() 
	{
		return numEmps;
	}
	
	//Returns the total number of hours worked over 
	//all the employees. 
	public double getTotalHours()
	{
		totHours += e.getHours();
		return totHours;
	}
	
	//Returns the total pay worked over all the employees.
	public double getTotalPay()
	{
		totPay += e.getPay();
	}
	
	//Removes the employee at position i if there is one and returns it. 
	//All other employees to the right should be moved over one position to the left. 
	//If i is out of range then return null.
	public Employee removeEmployee(int i)
	{
		if(i>=0 && i<numEmps) {
			Employee returnEmployee = emps[i];
			for(int j=i+1; j<numEmps; j++) {
				emps[j-1] = emps[j];
			}
			numEmps--;
			return returnEmployee;
		}
		return null;

	}
	
	//returns formatted message: payroll report & paystubs
	public String toString(Employee e, int totHours, int totPay, String str)
	{
		return "Payroll Report" +
				"\n Num Employees: " + numEmps + "," +
				"\total hrs:" + totHours + "," +
				"\ntotal pay:" + totPay + "," +  str;
	}
}

