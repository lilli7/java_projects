package application;

public interface Teleporter 
{
	String teleport(String dest);
}
