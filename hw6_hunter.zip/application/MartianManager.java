package application;

import java.util.ArrayList;
import java.util.Collections;

public class MartianManager
{
	protected ArrayList<Martian> martians = new ArrayList<>();
	protected ArrayList<Teleporter> teleporters = new ArrayList<>();
	
	MartianManager(){}
	
	public boolean addMartian(Martian m)
	{
		if(!martians.equals(m))
		{
			martians.add(m);
			if(m instanceof Teleporter)
				{
					teleporters.add((Teleporter) m);
				}
			return true;
		}
		
		else {return false;}
	}
	
	public ArrayList<Martian> battle(ArrayList<Martian> invaders)
	{
		ArrayList<Martian> deadMartians = new ArrayList<>();
		for(Martian i : invaders)
		{
			//make sure i doesn't repeat again
			for(Martian m : martians)
			{
				if(getPower(i) > getPower(m))
				{
					//Martian k = removeMartian(m.getId());
					deadMartians.add(m);
					break;
				}
			}
		}
		return deadMartians;
	}
	
	private int getPower(Martian m)
	{
		int power;
		power = m.getVolume();
		if(m instanceof RedMartian)
		{
			power = m.getVolume() + ((RedMartian) m).getTenacity();
		}
		
		return power;
	}
	
	public boolean contains(int id)
	{
		for(Martian m : martians)
		{
			if(m.getId() == id)
			{
				return true;
			}
		}

			return false;
	}
	
	public Martian getMartianAt(int i)
	{
		return martians.get(i);
	}
	
	public Martian getMartianClosestTo(int id)
	{
		int diff;
		int pos = 0;

		diff = Math.abs(martians.get(0).getId()-id);
		
		for(int i = 1; i < martians.size(); i++)
		{
			if((martians.get(i).getId() - id) < diff)
			{
				diff = martians.get(i).getId() - id;
				pos = i;
			}
		}
		return getMartianAt(pos);
	}
	
	public Martian getMartianClosestTo(Martian martian)
	{
		int diff;
		int pos = 0;

		diff = Math.abs(martians.get(0).getId()- martian.getId());
		
		for(int i = 1; i < martians.size(); i++)
		{
			if((martians.get(i).getId() - martian.getId()) < diff)
			{
				diff = martians.get(i).getId() - martian.getId();
				pos = i;
			}
		}
		return getMartianAt(pos);
	}
	
	public Martian getMartianWithId(int id)
	{
		for(Martian m : martians)
		{
			if(m.getId() == (id))
			{
				return m;
			}
		}
		return null;
	}
	
	public int getNumMartians()
	{
		return martians.size();
	}
	
	public int getNumTeleporters()
	{
		return teleporters.size();
	}
	
	// refer to page 16
	public ArrayList<Martian> getSortedMartians()
	{
		ArrayList<Martian> sortedMartians = new ArrayList<>(martians);
		Collections.sort(sortedMartians);
		return sortedMartians;
	}
	
	public Teleporter getTeleporterAt(int i)
	{
		return teleporters.get(i);
	}
	
	public String groupSpeak()
	{
		String msg = " ";
		for(Martian m : martians)
		{
			msg += m.speak() + "\n";
		}
		return msg;
	}

	public String groupTeleport(String dest)
	{
		String msg = " ";
		for(Martian m : martians)
		{
			if(m instanceof Teleporter)
			{
			msg += ((Teleporter) m).teleport(dest) + "\n";
			}
		}
		return msg;
	}
	
	public void obliterateTeleporters()
	{
		for(Martian m : martians)
		{
			if(m instanceof Teleporter)
			{
				martians.remove(m);
			}
		}
	}
	
	public Martian removeMartian(int id)
	{
		for(Martian m : martians)
		{
			if(m instanceof Teleporter)
			{
				if(m.equals(id))
				{
					martians.remove(m);
					return m;
				}
			}
		}
		
		for(Teleporter t : teleporters)
		{
			if(t instanceof Teleporter)
			{
				if(t.equals(id))
				{
					teleporters.remove(t);
				}
			}
		}
		return null;
	
	}
	
	public String toString()
	{
		String msg = " ";
		
		msg += ("Martians: " + groupSpeak());
		msg += "Teleporters";
		
		for(Martian m : martians)
		{
			if(m instanceof Teleporter)
			{
				msg += m.speak();
			}
		}

		return msg;
	}
}


