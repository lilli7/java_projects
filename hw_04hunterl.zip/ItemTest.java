package prob1;

public class ItemTest 
{
	public static void main (String[]args)
	{
		testItemCost();
		testItemToString();
		testRefrigeratedItem();
		testRefrigeratedItem2();
		testRefrigeratedItemCost();
		testRefrigeratedItemToString();
	}
	
	public static void testItemCost()
	{
		System.out.print("testItemCost()");
		Item item = new Item("crackers", 2);
		System.out.print("\nExpected:" + 4);
		System.out.print("\nActual" + "cost:" + item.cost());
		System.out.print("\n");
	}
	
	public static void testItemToString()
	{
		System.out.print("\ntestItemToString()");
		Item item = new Item("crackers", 2);
		System.out.print("\nExpected:" + "name=crackers, cost=$4.00, weight=2.00");
		System.out.print("\n"+ item.toString());
		System.out.print("\n");
	}
	
	public static void testRefrigeratedItem()
	{
		System.out.print("\ntestRefrigeratedItem()");
		RefrigeratedItem rI = new RefrigeratedItem("ice cream", 1.00, 20.00);
		System.out.print("\nExpected: " + "name=ice cream, cost=$10.00, weight=1.00, temp=20.00 degrees");
		System.out.print("\nActual: "+rI);
		System.out.print("\n");
	}
	
	public static void testRefrigeratedItem2()
	{
		System.out.print("\ntestRefrigeratedItem2()");
		Item item = new Item("ice cream", 1.00);
		RefrigeratedItem rI = new RefrigeratedItem(item, 20.00);
		System.out.print("\nExpected: " + "name=ice cream, cost=$10.00, weight=1.00, temp=20.00 degrees");
		System.out.print("\nActual"+rI);
		System.out.print("\n");
	}
	
	public static void testRefrigeratedItemCost()
	{
		System.out.print("\ntestRefrigeratedItemCost()");
		Item item = new Item("ice cream", 1.00);
		RefrigeratedItem rI = new RefrigeratedItem(item, 20.00);
		System.out.print("\nExpected: " + 10);
		System.out.print("\nActual: "+rI.cost());
		System.out.print("\n");
	}
	
	public static void testRefrigeratedItemToString()
	{
		System.out.print("\ntestRefrigeratedItemToString()");
		Item item = new Item("ice cream", 1.00);
		RefrigeratedItem rI = new RefrigeratedItem(item, 20.00);
		System.out.print("\nExpected: " + "name=ice cream, cost=$10.00, weight=1.00, temp=20.00 degrees");
		System.out.print("\nActual"+rI.toString());
		
	}
}
