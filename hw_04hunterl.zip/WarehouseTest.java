package prob1;

public class WarehouseTest 
{
	public static void main (String[]args)
	{
		testAddItem();
		testAddItem_11_Items();
		testAddItem_Multiple();
		testGetItem_WithIndex();
		testGetItem_WithIndex_4();
		testGetItem_WithName();
		testGetItem_WithInvalidName();
		testGetAverageTemp();
		testGetRefrigeratedItems();
		testGetRefrigeratedItems_NoRefrigeratedItems();
		testGetTotalCost();
		testGetTotalCostRefrigerated();
		testRemoveItem_WithIndex();
		testRemoveItem_WithInvalidIndex();
		testRemoveItem_WithName();
		testgetItemsWithName();
		testhasItem();
		testToString();
	}
	
	//Add one item and check the number of items to verify
	public static void testAddItem()
	{
		Warehouse w = new Warehouse();
		w.addItem(new Item("Ice cream", 2.5));
		
		System.out.println("testAddItem()");
		System.out.println("Expected:" + 1);
		System.out.println("Actual:" + w.getNumItems());
	}
	
	public static void testAddItem_11_Items()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		Item item6 = new RefrigeratedItem("Steak", 11, 10.00);
		Item item7 = new RefrigeratedItem("OJ", 10, 30.00);
		Item item8 = new RefrigeratedItem("Ketchup", 3, 20.00);
		Item item9 = new Item("Buns", 4);
		Item item10 = new RefrigeratedItem("Carrots", 5, 30.00);
		Item item11 = new RefrigeratedItem("Mayo", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		w.addItem(item6);
		w.addItem(item7);
		w.addItem(item8);
		w.addItem(item9);
		w.addItem(item10);
		w.addItem(item11);
		
		System.out.println();
		System.out.println("testAddItem_11_Items()");
		System.out.println("Expected:" + 11);
		System.out.println("Actual:" + w.getNumItems());
	}
	
	//Add three items and check the number of items to verify. At least one should be a refrigerated item
	public static void testAddItem_Multiple()
	{
		Warehouse w = new Warehouse();
		Item item = new Item("Ice cream", 2.5);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		System.out.println();
		System.out.println("testAddItem_Multiple()");
		System.out.println("Expected:" + 3);
		System.out.println("Actual:" + w.getNumItems());
	}
	
	//Add three items and retrieve the one at position 1
	public static void testGetItem_WithIndex()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		
		System.out.println();
		System.out.println("testGetItem_WithIndex()");
		System.out.println("Expected:" + "Crackers");
		System.out.println("Actual:" + w.getItem(1));
	}
	
	public static void testGetItem_WithIndex_4()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		
		System.out.println();
		System.out.println("testGetItem_WithIndex_4()");
		System.out.println("Expected:" + null);
		System.out.println("Actual:" + w.getItem(4));
	}
	
	//Add three items and try to find one with a name that exists
	public static void testGetItem_WithName()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		
		System.out.println();
		System.out.println("testGetItem_WithName()");
		System.out.println("Expected:" + "Hot dogs");
		System.out.println("Actual:" + w.getItem("Hot dogs"));
	}
	
	public static void testGetItem_WithInvalidName()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		
		System.out.println();
		System.out.println("testGetItem_WithInvalidName()");
		System.out.println("Expected:" + null);
		System.out.println("Actual:" + w.getItem("Mustard"));
	}
	//Add 5 items, 3 of which are refrigerated. Verify the average temperature
	public static void testGetAverageTemp()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		
		System.out.println();
		System.out.println("testGetAverageTemp()");
		System.out.println("Expected:" + 21.66);
		System.out.println("Actual:" + w.getAverageTemp());
	}
	
	//Add 5 items, 3 of which are refrigerated. Verify that the 3 are returned in array
	public static void testGetRefrigeratedItems()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		
		System.out.println();
		System.out.println("testGetRefrigeratedItems()");
		System.out.println("Expected:" + "Ice cream, Frozen dinner, Mustard");
		System.out.println("Actual:");
		System.out.println(w.getRefrigeratedItems());
	}
	
	public static void testGetRefrigeratedItems_NoRefrigeratedItems()
	{
		Warehouse w = new Warehouse();
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item2);
		w.addItem(item3);
		
		
		System.out.println();
		System.out.println("testGetRefrigeratedItems_NoRefrigeratedItems()");
		System.out.println("Expected:");
		System.out.println("Actual:");
		System.out.println(w.getRefrigeratedItems());
	}
	
	//Add 5 items, 3 of which is refrigerated. Verify the total cost.
	public static void testGetTotalCost()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		
		System.out.println();
		System.out.println("testGetTotalCost()");
		System.out.println("Expected:" + 52.5 + "dollars");
		System.out.println("Actual:" + w.getTotalCost());
	}
	//Add 5 items, 3 of which are refrigerated. Verify the total cost of the 3 refrigerated items
	public static void  testGetTotalCostRefrigerated()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		
		System.out.println();
		System.out.println("testGetTotalCostRefrigerated()");
		System.out.println("Expected:" + 44.5 + "dollars");
		System.out.println("Actual:" + w.getTotalCostRefrigerated());
	}
	//Add 5 items, 3 of which are refrigerated. Remove the one at position 2 and verify: the item is returned, and the number of items is decremented
	public static void testRemoveItem_WithIndex()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		
		System.out.println();
		System.out.println("testRemoveItem_WithIndex()");
		System.out.println("Expected:" + "Hot dogs" + "\nnum items: " + 4);
		System.out.println("Actual:" + w.removeItem(2) + "\nnum items: " + w.getNumItems());
	}
	
	public static void testRemoveItem_WithInvalidIndex()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		
		System.out.println();
		System.out.println("testRemoveItem_WithInvalidIndex()");
		System.out.println("Expected:" + null + "\nnum items: " + 5);
		System.out.println("Actual:" + w.removeItem(6) + "\nnum items: "+ w.getNumItems());
	}
	//Add 5 items, 3 of which are refrigerated. Remove one with a name that exisits and verify: the item is returned, and the number of items is decremented
	public static void testRemoveItem_WithName()
	{
		{
			Warehouse w = new Warehouse();
			Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
			Item item2 = new Item("Crackers", 1.0);
			Item item3 = new Item("Hot dogs", 3);
			Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
			Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
			
			w.addItem(item);
			w.addItem(item2);
			w.addItem(item3);
			w.addItem(item4);
			w.addItem(item5);
			
			System.out.println();
			System.out.println("testRemoveItem_WithName()");
			System.out.println("Expected:" + "Mustard" + "\nnum items: " + 4);
			System.out.println("Actual:" + w.removeItem("Mustard") + "\nnum items: " + w.getNumItems());
		}
	}
	
	public static void testRemoveItem_WithInvalidName()
	{
		{
			Warehouse w = new Warehouse();
			Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
			Item item2 = new Item("Crackers", 1.0);
			Item item3 = new Item("Hot dogs", 3);
			Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
			Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
			
			w.addItem(item);
			w.addItem(item2);
			w.addItem(item3);
			w.addItem(item4);
			w.addItem(item5);
			
			System.out.println();
			System.out.println("testRemoveItem_WithInvalidName()");
			System.out.println("Expected:" + null + "\nnum items: " + 5);
			System.out.println("Actual:" + w.removeItem("Ketchup") + "\nnum items: " + w.getNumItems());
		}
	}
	
	public static void testgetItemsWithName()
	{
		Warehouse w = new Warehouse();
		Item item = new Item("Ice cream", 2.5);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		
		System.out.println();
		System.out.println("testgetItemsWithName()");
		System.out.println("Expected:" + "Hot dogs");
		System.out.println("Actual:" + w.getItemsWithName("Hot"));
	}
	
	public static void testhasItem()
	{
		Warehouse w = new Warehouse();
		Item item = new Item("Ice cream", 2.5);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		
		System.out.println();
		System.out.println("testgetItemsWithName()");
		System.out.println("Expected:" + true);
		System.out.println("Actual:" + w.hasItem("Hot dogs"));
	}
	//Add 5 items, 3 of which are refrigerated. Verify that the result is correct.
	public static void testToString()
	{
		Warehouse w = new Warehouse();
		Item item = new RefrigeratedItem("Ice cream", 2.5, 20.00);
		Item item2 = new Item("Crackers", 1.0);
		Item item3 = new Item("Hot dogs", 3);
		Item item4 = new RefrigeratedItem("Frozen dinner", 5, 30.00);
		Item item5 = new RefrigeratedItem("Mustard", 3, 15.00);
		
		w.addItem(item);
		w.addItem(item2);
		w.addItem(item3);
		w.addItem(item4);
		w.addItem(item5);
		
		System.out.println();
		System.out.println("testToString()");
		System.out.println("Expected:" + "\nIce cream, 2.5, 20.00" +
							"\nCrackers, 1.0"+ 
							"\nHot dogs, 3"+
							"\nFrozen dinner, 5, 30.00"
							+"\nMustard, 3, 15.00");
		System.out.println("Actual:" + w.toString());
	}
}
