package prob1;
import java.util.ArrayList;

public class Warehouse 
{
	protected ArrayList<Item> items = new ArrayList<>();
	
	public Warehouse() { }
	
	public boolean addItem(Item item)
	{
			if(!items.equals(item))
			{
			items.add(item);
			return true;
			}
		return false;
	}
	
	public Item getItem(int i)
	{
		if(i >=0 && i < items.size()) {
			return items.get(i);
		}
		return null;
	}
	
	public Item getItem(String name)
	{
		Item dummyItem = new Item(name, 1);
		int pos = items.indexOf(dummyItem);
		if(pos >= 0) {
			return items.get(pos);
		}
		return null;
	}
	
	public int getNumItems()
	{
		return items.size();
	}
	//need help HERE
	public double getAverageTemp()
	{
		double totTemp = 0;
		double count = 0;
		for(Item i : items)
		{
			if(i instanceof RefrigeratedItem)
			{
				totTemp += (((RefrigeratedItem)i).getTemp());
				count++;
			}
		}
		return (totTemp/ count);
	}
	
	public ArrayList<RefrigeratedItem> getRefrigeratedItems()
	{
		ArrayList<RefrigeratedItem> rItems = new ArrayList<>();
		for(Item i : items)
		{
			if(i instanceof RefrigeratedItem)
			{
				rItems.add((RefrigeratedItem)i);
			}
		}
		return rItems;
	}
	
	public double getTotalCost()
	{
		double totCost = 0;
		for(Item i : items)
		{
			totCost += i.cost();
		}
		
		return totCost;
	}
	
	public double getTotalCostRefrigerated()
	{
		double totCostRef = 0;
		for(Item i : items)
		{
			if(i instanceof RefrigeratedItem)
			{
				totCostRef += i.cost();
			}
		}
		
		return totCostRef;
	}
	
	public Item removeItem(int i)
	{
		if(i >= 0 && i < items.size())
		{
			return items.remove(i);
		}
		return null;
	}
	
	public Item removeItem(String name)
	{
		Item itemKey = new Item(name, 1);
		int pos = items.indexOf(itemKey);
		if(pos>=0)
		{
			Item returnItem = items.get(pos);
			items.remove(itemKey);
			
			return returnItem;
		}
		return null;
	}
	
	public ArrayList<Item> getItemsWithName(String partialName)
	{
		ArrayList<Item> itemMatch = new ArrayList<>();
		int len = partialName.length();
		for(Item i : items)
		{
			if(i.getName().substring(0,len).equals(partialName)) {
				itemMatch.add(i);
			}
		}
		return itemMatch;
	}
	
	public boolean hasItem(String name)
	{
		for (Item i: items) {
			if(i.getName().equals(name)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String toString() 
	{
		String msg= "";
		for(Item i : items)
		{
			msg += i.toString() + "\n";
		}
		return msg;
	}
	
	
}
