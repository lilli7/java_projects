package animals;

public class Duck implements Flyer, Swimmer {

	@Override
	public String swim() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String dive() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String fly() {
		// TODO Auto-generated method stub
		return null;
	}

}
