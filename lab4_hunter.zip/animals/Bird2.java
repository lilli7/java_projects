package animals;

public class Bird2 implements Flyer {

	private String name;

	public Bird2(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	@Override
	public String fly() {
		return "bird flap-flap";
	}

}
