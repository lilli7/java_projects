package animals;

public class Bird extends Animal implements Flyer
{
	public Bird(String name) {
		super(name);
	}

	public String makeSound() {
		return "Chirp";
	}
}
