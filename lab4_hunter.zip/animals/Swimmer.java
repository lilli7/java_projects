package animals;

public interface Swimmer 
{
	public String swim();
	public String dive();
}
