package animals;

public interface Flyer 
{
	public String fly();
}
